"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

# Distutils version
#
# Updated automatically by the Python release process.
#
#--start constants--
__version__ = "3.4.3"
#--end constants--
